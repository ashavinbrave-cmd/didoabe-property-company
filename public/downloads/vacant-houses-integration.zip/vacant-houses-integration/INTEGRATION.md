# Vacant Houses – integration guide

Everything is **additive**: two new folders, no existing file is replaced.

```
src/features/vacant-houses/      components, data, types, utils, scoped CSS, index.ts
public/images/vacant-houses/     10 images, compressed (9 MB -> 2 MB), clean filenames
```

## 0. Apply (on the feature branch only)
```bash
git checkout main && git pull
git checkout -b feature/vacant-houses
./apply-to-repo.sh /path/to/didoabe-property-company   # refuses to run on main
```

## 1. Dependencies
The feature needs only `react` and `lucide-react`. The `motion` dependency from the
AI Studio export was removed (replaced by a small CSS animation).
If `lucide-react` is missing:  `npm install lucide-react`
Do NOT copy the zip's package.json / vite.config.ts / tsconfig.json / index.html /
App.tsx / main.tsx / index.css – they would conflict with your site.

Tailwind must scan `src/features/**` (default for most setups; check `content` in a v3 config).

## 2. Add the route (I could not see your router – use the matching option)
React Router:
```tsx
import { VacantHousesPage } from './features/vacant-houses';
<Route path="/vacant-houses" element={<VacantHousesPage />} />
```
State/hash-based router: render `<VacantHousesPage />` when your current page === 'vacant-houses'.

Cloudflare Pages SPA: if you use path routes, deep-link `/vacant-houses` already works
when your existing `_redirects`/SPA fallback handles other routes. Don't change deploy settings.

## 3. Add the nav link
Add one item to your existing nav array/JSX (desktop AND mobile menu), styled like its siblings:
`{ label: 'Vacant Houses', to: '/vacant-houses' }`

## 4. Before going live
- `data/vacantHousesData.ts`: replace placeholder WhatsApp (`256700000000`), phone, email, address in `DIDOABE_CONFIG`.
- Replace `SAMPLE_VACANT_HOUSES` with real listings (or pass `properties` prop). While `isSampleData` is true a "Demonstration Notice" strip is shown – it disappears for real data.
- Pass `onSubmitApplication` / `onSubmitVacantInquiry` to connect a backend. Until then the form clearly tells applicants it was NOT transmitted and offers WhatsApp instead.
- Typography: the page inherits your site fonts. Set `--vh-font-display` / `--vh-font-body` on `.vh-page` to override.

## 5. Verify in your repo
```bash
npm run build && npx tsc --noEmit
npm run dev   # check /, every existing page, /vacant-houses at 390px / 820px / 1440px
```
