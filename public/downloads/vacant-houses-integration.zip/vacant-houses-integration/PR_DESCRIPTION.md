## Add Vacant Houses page (feature/vacant-houses)

**Additive only.** New: `src/features/vacant-houses/**`, `public/images/vacant-houses/**`.
Modified (by hand, minimal): router (1 route) and nav (1 link). No other files changed.
No Cloudflare/deploy/config changes. Do not merge until reviewed.

### Changes made to the AI Studio export for safe integration
- Moved into one self-contained feature folder; imports fixed
- Removed `motion` dependency (CSS animation instead)
- Page styles scoped under `.vh-page` (no global CSS/fonts leak)
- Temporary header/footer off by default (site's real header/footer used)
- Images compressed 9 MB -> 2 MB, served from `/images/vacant-houses/`
- Removed developer-only text from the public demo notice
- Hero count text only says "demonstration" for sample data

### Test checklist
- [ ] `npm run build` passes   - [ ] `tsc --noEmit` passes
- [ ] Homepage and all existing pages unchanged   - [ ] `/vacant-houses` opens
- [ ] Nav link works (desktop + mobile menu)
- [ ] Search/filter/sort, View Details, Back, Apply, WhatsApp link
- [ ] Responsive at 390 / 820 / 1440 px
- [ ] Placeholder contact details replaced before launch
