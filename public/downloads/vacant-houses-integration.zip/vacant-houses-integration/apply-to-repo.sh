#!/usr/bin/env bash
# Copies the Vacant Houses feature into your repo. Safe by design:
#  - refuses to run on main/master or any branch other than feature/vacant-houses
#  - refuses to overwrite any existing file or folder
#  - does NOT commit, push, or touch routing/nav/config (you review those by hand)
# Usage:  ./apply-to-repo.sh /path/to/didoabe-property-company
set -euo pipefail
REPO="${1:?Usage: $0 /path/to/repo}"
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$REPO"
git rev-parse --is-inside-work-tree >/dev/null || { echo "Not a git repo"; exit 1; }
BRANCH="$(git rev-parse --abbrev-ref HEAD)"
if [ "$BRANCH" != "feature/vacant-houses" ]; then
  echo "ERROR: on '$BRANCH'. Run first:  git checkout -b feature/vacant-houses"; exit 1
fi
[ -z "$(git status --porcelain)" ] || { echo "ERROR: working tree not clean. Commit or stash first."; exit 1; }
for t in src/features/vacant-houses public/images/vacant-houses; do
  [ -e "$t" ] && { echo "ERROR: $t already exists - refusing to overwrite."; exit 1; }
done
mkdir -p src/features public/images
cp -R "$HERE/src/features/vacant-houses" src/features/vacant-houses
cp -R "$HERE/public/images/vacant-houses" public/images/vacant-houses
echo "Copied. New files only:"; git status --short
echo; echo "Next: follow INTEGRATION.md (route + nav link + deps), then build."
